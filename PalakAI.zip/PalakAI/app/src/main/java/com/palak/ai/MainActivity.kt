package com.palak.ai

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var askedOverlay = false

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            // Bridge phone control tak pahunchata hai, isliye sirf apni asset file chalegi
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true
            }
            addJavascriptInterface(PalakJSBridge(), "PalakAndroid")
            loadUrl("file:///android_asset/palak_3d_ui.html")
        }
        setContentView(webView)
        requestNeededPermissions()
    }

    override fun onResume() {
        super.onResume()
        PalakBus.listener = { type, text -> pushToUi(type, text) }
        pushToUi("status", if (PalakBus.running) "on" else "off")
    }

    override fun onPause() {
        PalakBus.listener = null
        super.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun pushToUi(type: String, text: String) {
        val js = "if(window.palakEvent)palakEvent(${JSONObject.quote(type)},${JSONObject.quote(text)})"
        webView.evaluateJavascript(js, null)
    }

    private fun hasPermission(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestNeededPermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val missing = needed.filter { !hasPermission(it) }
        if (missing.isEmpty()) afterPermissions()
        else ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101) afterPermissions()
    }

    private fun afterPermissions() {
        startVoiceService() // pehle service (app abhi foreground mein hai), phir overlay
        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun startVoiceService() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) return
        ContextCompat.startForegroundService(this, Intent(this, PalakVoiceService::class.java))
    }

    inner class PalakJSBridge {
        @JavascriptInterface
        fun openAccessibilitySettings() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        @JavascriptInterface
        fun startListening() = runOnUiThread {
            if (hasPermission(Manifest.permission.RECORD_AUDIO)) startVoiceService()
            else requestNeededPermissions()
        }

        @JavascriptInterface
        fun stopListening() = runOnUiThread {
            stopService(Intent(this@MainActivity, PalakVoiceService::class.java))
        }

        @JavascriptInterface
        fun isRunning(): Boolean = PalakBus.running

        @JavascriptInterface
        fun runCommand(text: String) = runOnUiThread {
            PalakBrain.processCommand(this@MainActivity, text) { PalakBus.emit("reply", it) }
        }
    }
}
