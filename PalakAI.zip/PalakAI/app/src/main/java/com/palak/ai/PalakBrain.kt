package com.palak.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Service aur UI ke beech status/jawab bhejne ka chhota rasta. */
object PalakBus {
    @Volatile
    var running = false
        private set

    @Volatile
    var listener: ((String, String) -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun setRunning(on: Boolean) {
        running = on
        emit("status", if (on) "on" else "off")
    }

    fun emit(type: String, text: String) {
        main.post { listener?.invoke(type, text) }
    }
}

object PalakBrain {

    // Google AI Studio se free key lekar yahan daaliye. APK kisi ko share na karein.
    private const val GEMINI_API_KEY = "YOUR_FREE_GEMINI_API_KEY"
    private const val SYSTEM_RULE =
        "Tumhara naam Palak hai. Tum ek smart Hindi/Hinglish voice assistant ho. " +
            "Chhote aur clear jawab do, bina markdown ke. Image ya video generation kabhi mat karna."

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val callFillers = setOf(
        "call", "कॉल", "karo", "kar", "karna", "do", "dena", "lagao", "laga", "लगाओ", "करो", "कर",
        "को", "ko", "to", "please", "phone", "number", "नंबर", "pe", "par", "पर", "पे"
    )

    fun processCommand(context: Context, rawCmd: String, onReply: (String) -> Unit) {
        val cmd = rawCmd.lowercase().trim()
        val w = cmd.split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }.toSet()
        fun has(vararg keys: String) = keys.any { it in w }
        val access = PalakControlService.instance
        fun needAccess(block: (PalakControlService) -> String) =
            onReply(access?.let(block) ?: "Pehle Accessibility permission on kijiye.")

        when {
            // Image/video generation band
            has("image", "photo", "इमेज", "फोटो", "तस्वीर", "video", "वीडियो") &&
                has("banao", "bana", "बनाओ", "बना", "generate", "create") ->
                onReply("Maaf kijiye, main image aur video generate nahi karti. Baki koi bhi kaam bataiye.")

            cmd.startsWith("click ") || cmd.startsWith("क्लिक ") || cmd.startsWith("tap ") -> {
                val target = cmd.substringAfter(' ').trim()
                needAccess { if (it.clickByText(target)) "$target par click kar diya." else "$target screen par nahi mila." }
            }
            cmd.startsWith("type ") || cmd.startsWith("likho ") || cmd.startsWith("लिखो ") -> {
                val t = cmd.substringAfter(' ').trim()
                needAccess { if (it.typeText(t)) "Likh diya." else "Likhne ke liye koi text box nahi mila." }
            }

            has("wifi", "wi-fi", "वाईफाई", "वाईफ़ाई", "वाई-फाई") -> {
                val ok = launch(context, Intent(Settings.ACTION_WIFI_SETTINGS))
                onReply(if (ok) "Wi-Fi settings khol di hain." else "Wi-Fi settings nahi khul paayi.")
            }
            has("settings", "सेटिंग", "सेटिंग्स") -> {
                val ok = launch(context, Intent(Settings.ACTION_SETTINGS))
                onReply(if (ok) "Settings khol di hain." else "Settings nahi khul paayi.")
            }
            has("youtube", "यूट्यूब", "यूटयूब") ->
                openApp(context, "com.google.android.youtube", "YouTube", onReply)
            has("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप") ->
                openApp(context, "com.whatsapp", "WhatsApp", onReply)
            has("call", "कॉल") -> makeCall(context, cmd, onReply)

            has("upar", "ऊपर") -> needAccess { it.scrollUp(); "Screen upar scroll kar di hai." }
            has("scroll", "स्क्रॉल", "neeche", "नीचे") -> needAccess { it.scrollDown(); "Screen neeche scroll kar di hai." }
            has("back", "peeche", "पीछे", "वापस") -> needAccess { it.goBack(); "Peeche aa gayi hoon." }
            has("home", "होम") -> needAccess { it.goHome(); "Home screen par aa gayi hoon." }
            has("recent", "recents", "रिसेंट") -> needAccess { it.openRecents(); "Recent apps khol diye hain." }
            has("notification", "notifications", "नोटिफिकेशन") ->
                needAccess { it.openNotifications(); "Notifications khol diye hain." }

            else -> askFreeAI(cmd, onReply)
        }
    }

    private fun launch(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    private fun openApp(context: Context, pkg: String, name: String, onReply: (String) -> Unit) {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null && launch(context, intent)) onReply("$name khol rahi hoon.")
        else onReply("Phone mein $name app nahi mila.")
    }

    private fun makeCall(context: Context, cmd: String, onReply: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            onReply("Call ki permission nahi mili."); return
        }
        val digits = cmd.filter { it.isDigit() }.map { Character.digit(it, 10) }.joinToString("")
        var number: String? = if (digits.length >= 10) digits else null
        var label = digits
        if (number == null) {
            val name = cmd.split(Regex("\\s+")).filter { it !in callFillers }.joinToString(" ").trim()
            if (name.isEmpty()) { onReply("Kripya naam ya pura number boliye."); return }
            number = findContact(context, name)
            if (number == null) { onReply("$name naam ka contact nahi mila."); return }
            label = name
        }
        val ok = launch(context, Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
        onReply(if (ok) "$label ko call laga rahi hoon." else "Call nahi lag paayi.")
    }

    private fun findContact(context: Context, name: String): String? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use { c ->
            if (c.moveToFirst()) return c.getString(0)?.filter { it.isDigit() || it == '+' }
        }
        return null
    }

    private fun askFreeAI(prompt: String, onReply: (String) -> Unit) {
        if (GEMINI_API_KEY.startsWith("YOUR_")) {
            onReply("Gemini API key abhi nahi lagi hai. PalakBrain.kt mein key daaliye."); return
        }
        scope.launch {
            val reply = try {
                callGemini(prompt)
            } catch (e: Exception) {
                "Network check kijiye, abhi jawab nahi mil paaya."
            }
            withContext(Dispatchers.Main) { onReply(reply) }
        }
    }

    private fun callGemini(prompt: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 20_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", GEMINI_API_KEY)
        }
        try {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_RULE))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode !in 200..299) return "Abhi jawab nahi mil paaya (error ${conn.responseCode})."
            val text = JSONObject(conn.inputStream.bufferedReader().readText())
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
            return text.replace(Regex("[*#_`>~]"), "").trim() // TTS symbols na bole
        } finally {
            conn.disconnect()
        }
    }
}
