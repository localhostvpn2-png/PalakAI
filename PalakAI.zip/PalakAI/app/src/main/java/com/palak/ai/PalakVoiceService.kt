package com.palak.ai

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import java.util.Locale

class PalakVoiceService : Service(), TextToSpeech.OnInitListener {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private lateinit var recognizerIntent: Intent
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var destroyed = false
    private var commandUntil = 0L

    // Recognizer kabhi Roman, kabhi Devanagari mein likhta hai
    private val wakeWords = listOf("hey palak", "हे पलक", "palak", "पलक", "पालक")
    private val startRunnable = Runnable { listen() }

    override fun onCreate() {
        super.onCreate()
        if (!startAsForeground() ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            PalakBus.emit("reply", "Is phone mein speech recognition available nahi hai.")
            stopSelf(); return
        }
        tts = TextToSpeech(this, this)
        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        PalakBus.setRunning(true)
        listen()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    private fun startAsForeground(): Boolean = try {
        val channelId = "palak_voice_channel"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "Palak AI Assistant", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Palak AI Active")
            .setContentText("'Hey Palak' bol kar koi bhi kaam karwayein")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        true
    } catch (e: Exception) {
        false
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.lowercase(Locale.ROOT)?.trim().orEmpty()
            if (text.isNotEmpty()) handleSpeech(text)
            scheduleListen(400)
        }

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                stopSelf(); return
            }
            // Turant restart karne se loop banta hai, isliye delay
            scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 700)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleSpeech(text: String) {
        if (wakeWords.any { text.contains(it) }) {
            var cmd = text
            wakeWords.forEach { cmd = cmd.replace(it, " ") }
            cmd = cmd.trim()
            if (cmd.isEmpty()) {
                commandUntil = SystemClock.elapsedRealtime() + 10_000
                speak("Haan boliye, main sun rahi hoon.")
            } else {
                commandUntil = 0
                run(cmd)
            }
        } else if (SystemClock.elapsedRealtime() < commandUntil) {
            commandUntil = 0
            run(text)
        }
    }

    private fun run(cmd: String) {
        PalakBus.emit("heard", cmd)
        PalakBrain.processCommand(this, cmd) { speak(it) }
    }

    private fun speak(text: String) {
        PalakBus.emit("reply", text)
        if (ttsReady) {
            speaking = true
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "PALAK_REPLY")
        }
    }

    private fun scheduleListen(delayMs: Long) {
        if (destroyed) return
        handler.removeCallbacks(startRunnable)
        handler.postDelayed(startRunnable, delayMs)
    }

    private fun listen() {
        if (destroyed || speaking) return // bolte waqt khud ki awaaz na sune
        try {
            recognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
        }
    }

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        val r = engine.setLanguage(Locale.forLanguageTag("hi-IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { speaking = false; scheduleListen(300) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { speaking = false; scheduleListen(300) }
            }
        })
        ttsReady = true
    }

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        PalakBus.setRunning(false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
